package com.ecocultura.florida;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class MlocationsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private FloatingActionButton _fab;
	private String id = "";
	
	private ArrayList<HashMap<String, Object>> lmplaces = new ArrayList<>();
	
	private LinearLayout main;
	private CardView boxHeader;
	private LinearLayout BoxEmpty;
	private LinearLayout BoxLoading;
	private ListView lvplaces;
	private LinearLayout linear2;
	private LinearLayout btnToggleSidebar;
	private TextView textview1;
	private ImageView imageview2;
	private TextView textview2;
	private ProgressBar progressbar1;
	
	private DatabaseReference dbplaces = _firebase.getReference("places");
	private ChildEventListener _dbplaces_child_listener;
	private AlertDialog.Builder d;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.mlocations);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		BoxEmpty = findViewById(R.id.BoxEmpty);
		BoxLoading = findViewById(R.id.BoxLoading);
		lvplaces = findViewById(R.id.lvplaces);
		linear2 = findViewById(R.id.linear2);
		btnToggleSidebar = findViewById(R.id.btnToggleSidebar);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		textview2 = findViewById(R.id.textview2);
		progressbar1 = findViewById(R.id.progressbar1);
		d = new AlertDialog.Builder(this);
		
		btnToggleSidebar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivity.i.setClass(getApplicationContext(), AddplaceActivity.class);
				startActivity(MainActivity.i);
			}
		});
		
		_dbplaces_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childValue.get("id").toString().equals(id)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Successfully deleted");
					_LoadPlaces();
				}
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbplaces.addChildEventListener(_dbplaces_child_listener);
	}
	
	private void initializeLogic() {
	}
	
	@Override
	public void onResume() {
		super.onResume();
		_LoadPlaces();
	}
	public void _LoadPlaces() {
		BoxLoading.setVisibility(View.VISIBLE);
		BoxEmpty.setVisibility(View.GONE);
		lvplaces.setVisibility(View.GONE);
		dbplaces.addListenerForSingleValueEvent(new ValueEventListener() {
			@Override
			public void onDataChange(DataSnapshot _dataSnapshot) {
				lmplaces = new ArrayList<>();
				try {
					GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
					for (DataSnapshot _data : _dataSnapshot.getChildren()) {
						HashMap<String, Object> _map = _data.getValue(_ind);
						lmplaces.add(_map);
					}
				}
				catch (Exception _e) {
					_e.printStackTrace();
				}
				BoxLoading.setVisibility(View.GONE);
				if (lmplaces.size() > 0) {
					lvplaces.setVisibility(View.VISIBLE);
					lvplaces.setAdapter(new LvplacesAdapter(lmplaces));
					((BaseAdapter)lvplaces.getAdapter()).notifyDataSetChanged();
				}
				else {
					BoxEmpty.setVisibility(View.VISIBLE);
				}
			}
			@Override
			public void onCancelled(DatabaseError _databaseError) {
			}
		});
	}
	
	public class LvplacesAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public LvplacesAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cvplaces, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView name = _view.findViewById(R.id.name);
			final TextView address = _view.findViewById(R.id.address);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final Button btnEdit = _view.findViewById(R.id.btnEdit);
			final Button btnDelete = _view.findViewById(R.id.btnDelete);
			
			name.setText(_data.get((int)_position).get("name").toString());
			address.setText(_data.get((int)_position).get("address").toString());
			// Radius
			int _ButtonLeftTop = 8;
			int _ButtonRightTop = 8;
			int _ButtonRightBottom = 8;
			int _ButtonLeftBottom = 8;
			// Border
			int _ButtonBorderColor = Color.TRANSPARENT;
			int _ButtonBorderStroke = 0;
			//Background
			int _ButtonBackgroundColor = Color.TRANSPARENT;
			int _ButtonRippleColor = Color.TRANSPARENT;
			
			AJCode.setRoundedRipple(btnEdit,_ButtonLeftTop,_ButtonRightTop,_ButtonRightBottom,_ButtonLeftBottom,0xFF3A5245,_ButtonBorderStroke,_ButtonBorderColor,0xFFC8E6C9);
			AJCode.setRoundedRipple(btnDelete,_ButtonLeftTop,_ButtonRightTop,_ButtonRightBottom,_ButtonLeftBottom,0xFFEF5350,_ButtonBorderStroke,_ButtonBorderColor,0xFFFFCDD2);
			btnEdit.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.putExtra("id", _data.get((int)_position).get("id").toString());
					i.putExtra("data", new Gson().toJson(_data.get((int)(_position))));
					i.setClass(getApplicationContext(), AddplaceActivity.class);
					startActivity(i);
				}
			});
			btnDelete.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					d.setTitle("Are you sure?");
					d.setMessage("Do you want to delete this?");
					d.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							id = _data.get((int)_position).get("id").toString();
							dbplaces.child(id).removeValue();
							SketchwareUtil.showMessage(getApplicationContext(), "Deleting please wait...");
						}
					});
					d.setNegativeButton("No", new DialogInterface.OnClickListener() {
						@Override
						public void onClick(DialogInterface _dialog, int _which) {
							
						}
					});
					d.create().show();
				}
			});
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}