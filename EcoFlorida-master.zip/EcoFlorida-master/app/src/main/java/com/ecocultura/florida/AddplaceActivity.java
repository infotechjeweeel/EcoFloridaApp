package com.ecocultura.florida;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Build;
import android.provider.MediaStore;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.io.File;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class AddplaceActivity extends AppCompatActivity {
	
	public final int REQ_CD_FP = 101;
	public final int REQ_CD_FP360IMAGE = 102;
	public final int REQ_CD_FPBROWSE360IMAGE = 103;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private HashMap<String, Object> details = new HashMap<>();
	private String id = "";
	public static String address;
	public static String latitude;
	public static String longitude;
	private String lat = "";
	private String lng = "";
	private HashMap<String, Object> mapgallery = new HashMap<>();
	private String filePath = "";
	private boolean hasthumbnail = false;
	private double SelectedThumbnailIndex = 0;
	private double GalleryPicturesCount = 0;
	private double SuccessfulUploaded = 0;
	private String fileExtension = "";
	private String fileName = "";
	private double UploadingIndex = 0;
	private boolean ReadyToSave = false;
	private boolean UpdateAction = false;
	private String imageDownloadUrl = "";
	private String image360downdloadlink = "";
	private String base64 = "";
	private String extension = "";
	private HashMap<String, Object> rnMap = new HashMap<>();
	private HashMap<String, Object> resMap = new HashMap<>();
	
	private ArrayList<String> category = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmgallery = new ArrayList<>();
	
	private LinearLayout main;
	private CardView boxHeader;
	private ScrollView vs;
	private LinearLayout linear2;
	private LinearLayout btnToggleSidebar;
	private TextView textview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private CardView cardview1;
	private LinearLayout BoxForm;
	private LinearLayout linear15;
	private LinearLayout inputField;
	private LinearLayout linear6;
	private Button BtnLocation;
	private LinearLayout linear7;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout linear13;
	private LinearLayout BoxGallery;
	private LinearLayout BtnSave;
	private CardView cardview2;
	private Button btnCapture360Image;
	private Button buttonBrowseImage;
	private ImageView preview360image;
	private TextView textview3;
	private EditText tbname;
	private TextView textview4;
	private EditText tbaddress;
	private TextView textview5;
	private EditText tbdescription;
	private TextView textview10;
	private EditText tboperationhours;
	private TextView textview14;
	private EditText tbcontacts;
	private TextView textview11;
	private LinearLayout tbcategory;
	private Spinner spnrcategory;
	private TextView textview12;
	private RecyclerView rvgallery;
	private LinearLayout BoxEmpty;
	private Button BtnAddImage;
	private TextView textview13;
	private TextView textview6;
	
	private DatabaseReference db = _firebase.getReference("places");
	private ChildEventListener _db_child_listener;
	private StorageReference storage = _firebase_storage.getReference("images");
	private OnCompleteListener<Uri> _storage_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _storage_download_success_listener;
	private OnSuccessListener _storage_delete_success_listener;
	private OnProgressListener _storage_upload_progress_listener;
	private OnProgressListener _storage_download_progress_listener;
	private OnFailureListener _storage_failure_listener;
	
	private Intent fp = new Intent(Intent.ACTION_GET_CONTENT);
	private TimerTask tmr;
	private ProgressDialog pd;
	private Intent fp360image = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
	private File _file_fp360image;
	private Intent i = new Intent();
	private AlertDialog.Builder d;
	private StorageReference fs360 = _firebase_storage.getReference("galleries/360");
	private OnCompleteListener<Uri> _fs360_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _fs360_download_success_listener;
	private OnSuccessListener _fs360_delete_success_listener;
	private OnProgressListener _fs360_upload_progress_listener;
	private OnProgressListener _fs360_download_progress_listener;
	private OnFailureListener _fs360_failure_listener;
	
	private Intent fpBrowse360Image = new Intent(Intent.ACTION_GET_CONTENT);
	private RequestNetwork rn;
	private RequestNetwork.RequestListener _rn_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.addplace);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		vs = findViewById(R.id.vs);
		linear2 = findViewById(R.id.linear2);
		btnToggleSidebar = findViewById(R.id.btnToggleSidebar);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		cardview1 = findViewById(R.id.cardview1);
		BoxForm = findViewById(R.id.BoxForm);
		linear15 = findViewById(R.id.linear15);
		inputField = findViewById(R.id.inputField);
		linear6 = findViewById(R.id.linear6);
		BtnLocation = findViewById(R.id.BtnLocation);
		linear7 = findViewById(R.id.linear7);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		linear13 = findViewById(R.id.linear13);
		BoxGallery = findViewById(R.id.BoxGallery);
		BtnSave = findViewById(R.id.BtnSave);
		cardview2 = findViewById(R.id.cardview2);
		btnCapture360Image = findViewById(R.id.btnCapture360Image);
		buttonBrowseImage = findViewById(R.id.buttonBrowseImage);
		preview360image = findViewById(R.id.preview360image);
		textview3 = findViewById(R.id.textview3);
		tbname = findViewById(R.id.tbname);
		textview4 = findViewById(R.id.textview4);
		tbaddress = findViewById(R.id.tbaddress);
		textview5 = findViewById(R.id.textview5);
		tbdescription = findViewById(R.id.tbdescription);
		textview10 = findViewById(R.id.textview10);
		tboperationhours = findViewById(R.id.tboperationhours);
		textview14 = findViewById(R.id.textview14);
		tbcontacts = findViewById(R.id.tbcontacts);
		textview11 = findViewById(R.id.textview11);
		tbcategory = findViewById(R.id.tbcategory);
		spnrcategory = findViewById(R.id.spnrcategory);
		textview12 = findViewById(R.id.textview12);
		rvgallery = findViewById(R.id.rvgallery);
		BoxEmpty = findViewById(R.id.BoxEmpty);
		BtnAddImage = findViewById(R.id.BtnAddImage);
		textview13 = findViewById(R.id.textview13);
		textview6 = findViewById(R.id.textview6);
		fp.setType("image/*");
		fp.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		_file_fp360image = FileUtil.createNewPictureFile(getApplicationContext());
		Uri _uri_fp360image;
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
			_uri_fp360image = FileProvider.getUriForFile(getApplicationContext(), getApplicationContext().getPackageName() + ".provider", _file_fp360image);
		} else {
			_uri_fp360image = Uri.fromFile(_file_fp360image);
		}
		fp360image.putExtra(MediaStore.EXTRA_OUTPUT, _uri_fp360image);
		fp360image.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
		d = new AlertDialog.Builder(this);
		fpBrowse360Image.setType("image/*");
		fpBrowse360Image.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		rn = new RequestNetwork(this);
		
		btnToggleSidebar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		BtnLocation.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivity.i.setClass(getApplicationContext(), MapActivity.class);
				startActivity(MainActivity.i);
			}
		});
		
		BtnSave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (tbname.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter the place name");
					return;
				}
				if (tbaddress.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter the address or select a location");
					return;
				}
				if (lat.equals("") || lng.equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please select a location");
					return;
				}
				if (tbdescription.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter the description");
					return;
				}
				if (tboperationhours.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter the operation hours");
					return;
				}
				if (tbcontacts.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter the contact information");
					return;
				}
				if (lmgallery.size() == 0) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please upload pictures for gallery");
					return;
				}
				hasthumbnail = false;
				for(int _repeat75 = 0; _repeat75 < (int)(lmgallery.size()); _repeat75++) {
					if (lmgallery.get((int)_repeat75).get("thumbnail").toString().equals("yes")) {
						hasthumbnail = true;
					}
				}
				if (!hasthumbnail) {
					SketchwareUtil.showMessage(getApplicationContext(), "You dont have selected thumbnail");
					return;
				}
				GalleryPicturesCount = lmgallery.size();
				SuccessfulUploaded = 0;
				UploadingIndex = 0;
				pd.setTitle("Uploading images is in Progress");
				pd.setMessage("Warning : Please dont exit the app");
				pd.setMax((int)GalleryPicturesCount);
				pd.setProgress((int)SuccessfulUploaded);
				pd.setCancelable(false);
				pd.setCanceledOnTouchOutside(false);
				pd.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
				pd.show();
				_StartUploading();
			}
		});
		
		btnCapture360Image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp360image, REQ_CD_FP360IMAGE);
			}
		});
		
		buttonBrowseImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fpBrowse360Image, REQ_CD_FPBROWSE360IMAGE);
			}
		});
		
		BtnAddImage.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(fp, REQ_CD_FP);
			}
		});
		
		_db_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (ReadyToSave) {
					if (id.equals(_childKey)) {
						SketchwareUtil.showMessage(getApplicationContext(), "Successfully Saved");
						finish();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (ReadyToSave) {
					if (id.equals(_childKey)) {
						SketchwareUtil.showMessage(getApplicationContext(), "Successfully Saved");
						finish();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		db.addChildEventListener(_db_child_listener);
		
		_storage_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_storage_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				if (!(SuccessfulUploaded == GalleryPicturesCount)) {
					SuccessfulUploaded++;
					pd.setProgress((int)SuccessfulUploaded);
					lmgallery.get((int)UploadingIndex).put("fileDownloadUrl", _downloadUrl);
					lmgallery.get((int)UploadingIndex).put("uploaded", "yes");
					UploadingIndex++;
					_StartUploading();
				}
			}
		};
		
		_storage_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_storage_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_storage_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_fs360_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs360_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_fs360_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				image360downdloadlink = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(preview360image);
				pd.dismiss();
			}
		};
		
		_fs360_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_fs360_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_fs360_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_rn_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				pd.dismiss();
				try {
					if (_tag.equals("UploadImage")) {
						resMap = new Gson().fromJson(_response, new TypeToken<HashMap<String, Object>>(){}.getType());
						image360downdloadlink = resMap.get("preview").toString();
					}
				} catch (Exception e) {
					SketchwareUtil.showMessage(getApplicationContext(), "Failed to upload something went wrong to the server");
				}
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
	}
	
	private void initializeLogic() {
		_design();
		pd = new ProgressDialog(AddplaceActivity.this);
		if (getIntent().hasExtra("id")) {
			textview1.setText("EDIT PLACE DETAILS");
			UpdateAction = true;
			id = getIntent().getStringExtra("id");
			details = new Gson().fromJson(getIntent().getStringExtra("data"), new TypeToken<HashMap<String, Object>>(){}.getType());
			tbname.setText(details.get("name").toString());
			tbaddress.setText(details.get("address").toString());
			tbdescription.setText(details.get("description").toString());
			tboperationhours.setText(details.get("operation_hours").toString());
			tbcontacts.setText(details.get("contact_information").toString());
			Glide.with(getApplicationContext()).load(Uri.parse(details.get("360view").toString())).into(preview360image);
			lat = details.get("coordinate_lat").toString();
			lng = details.get("coordinate_lng").toString();
			lmgallery = new Gson().fromJson(details.get("gallery").toString(), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
			_updateRvGallery();
		}
		else {
			UpdateAction = false;
			id = db.push().getKey();
		}
		ReadyToSave = false;
		category.add("Cultural Sites");
		category.add("Ecological Sites");
		spnrcategory.setAdapter(new ArrayAdapter<String>(getBaseContext(), android.R.layout.simple_spinner_dropdown_item, category));
		((ArrayAdapter)spnrcategory.getAdapter()).notifyDataSetChanged();
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_FP:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				filePath = _filePath.get((int)(0));
				fileName = String.valueOf((long)(SketchwareUtil.getRandom((int)(1000), (int)(9999)))).concat(Uri.parse(filePath).getLastPathSegment());
				try {
					if (FileUtil.isExistFile(filePath)) {
						mapgallery = new HashMap<>();
						mapgallery.put("filePath", filePath);
						mapgallery.put("thumbnail", "no");
						mapgallery.put("fileName", fileName);
						mapgallery.put("uploaded", "no");
						lmgallery.add(mapgallery);
						_updateRvGallery();
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "File is not exist");
					}
				} catch (Exception e) {
					SketchwareUtil.showMessage(getApplicationContext(), "Invalid File Path");
				}
			}
			else {
				
			}
			break;
			
			case REQ_CD_FP360IMAGE:
			if (_resultCode == Activity.RESULT_OK) {
				 String _filePath = _file_fp360image.getAbsolutePath();
				
				filePath = _filePath;
				fileName = String.valueOf((long)(SketchwareUtil.getRandom((int)(1000), (int)(9999)))).concat(Uri.parse(filePath).getLastPathSegment());
				fs360.child(fileName).putFile(Uri.fromFile(new File(filePath))).addOnFailureListener(_fs360_failure_listener).addOnProgressListener(_fs360_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return fs360.child(fileName).getDownloadUrl();
					}}).addOnCompleteListener(_fs360_upload_success_listener);
				pd.setMessage("Uploading 360 image please wait");
				pd.setCancelable(false);
				pd.show();
			}
			else {
				
			}
			break;
			
			case REQ_CD_FPBROWSE360IMAGE:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				filePath = _filePath.get((int)(0));
				preview360image.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(filePath, 1024, 1024));
				base64 = _ImageViewToBase64(preview360image);
				fileExtension = _GetFileExtension(filePath);
				rnMap = new HashMap<>();
				rnMap.put("IMAGE", base64);
				rnMap.put("EXTENSION", fileExtension);
				rn.setParams(rnMap, RequestNetworkController.REQUEST_PARAM);
				rn.startRequestNetwork(RequestNetworkController.POST, "https://ecoflorida.fuxdevs.com/upload-image.php", "UploadImage", _rn_request_listener);
				pd.setMessage("Uploading 360 image please wait");
				pd.setCancelable(false);
				pd.show();
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	@Override
	public void onResume() {
		super.onResume();
		try {
			details = new Gson().fromJson(MainActivity.sp.getString("mapdetails", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
			if (details.size() > 0) {
				tbaddress.setText(details.get("complete_address").toString());
				lat = details.get("latitude").toString();
				lng = details.get("longitude").toString();
				MainActivity.sp.edit().putString("mapdetails", "[]").commit();
			}
		} catch (Exception e) {
			 
		}
	}
	public void _design() {
		btnCapture360Image.setVisibility(View.GONE);
		AJCode.setRoundedRipple(BtnSave,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFC8E6C9);
		AJCode.setRoundedRipple(BtnLocation,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFC8E6C9);
		AJCode.setRoundedRipple(BtnAddImage,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFC8E6C9);
		AJCode.setRoundedRipple(buttonBrowseImage,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFC8E6C9);
		// Radius
		int _TbLeftTop = 8;
		int _TbRightTop = 8;
		int _TbRightBottom = 8;
		int _TbLeftBottom = 8;
		// Border
		int _TbBorderColor = 0xFF3A5245;
		int _TbBorderStroke = 2;
		//Background
		int _TbBackgroundColor = 0xFFFEFAF6;
		int _TbRippleColor = Color.TRANSPARENT;
		
		AJCode.setRoundedRipple(tbname,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
		AJCode.setRoundedRipple(tbaddress,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
		AJCode.setRoundedRipple(tbdescription,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
		AJCode.setRoundedRipple(tboperationhours,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
		AJCode.setRoundedRipple(tbcategory,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
		AJCode.setRoundedRipple(tbcontacts,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
	}
	
	
	public void _updateRvGallery() {
		rvgallery.setVisibility(View.GONE);
		BoxEmpty.setVisibility(View.GONE);
		if (lmgallery.size() == 0) {
			BoxEmpty.setVisibility(View.VISIBLE);
		}
		else {
			rvgallery.setVisibility(View.VISIBLE);
			rvgallery.setAdapter(new RvgalleryAdapter(lmgallery));
			rvgallery.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		}
	}
	
	
	public void _SelectThumbnail(final double _idx) {
		SelectedThumbnailIndex = _idx;
		for(int _repeat10 = 0; _repeat10 < (int)(lmgallery.size()); _repeat10++) {
			if (!(_idx == _repeat10)) {
				lmgallery.get((int)_repeat10).put("thumbnail", "no");
			}
		}
		lmgallery.get((int)_idx).put("thumbnail", "yes");
		_updateRvGallery();
	}
	
	
	public void _StartUploading() {
		if (!(SuccessfulUploaded == GalleryPicturesCount)) {
			if (lmgallery.get((int)UploadingIndex).get("uploaded").toString().equals("yes")) {
				UploadingIndex++;
				SuccessfulUploaded++;
				pd.setProgress((int)UploadingIndex);
				_StartUploading();
			}
			else {
				storage.child(lmgallery.get((int)UploadingIndex).get("fileName").toString()).putFile(Uri.fromFile(new File(lmgallery.get((int)UploadingIndex).get("filePath").toString()))).addOnFailureListener(_storage_failure_listener).addOnProgressListener(_storage_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return storage.child(lmgallery.get((int)UploadingIndex).get("fileName").toString()).getDownloadUrl();
					}}).addOnCompleteListener(_storage_upload_success_listener);
			}
		}
		else {
			ReadyToSave = true;
			pd.setTitle("Saving the place details");
			pd.setMessage("Warning : Please dont exit the app");
			pd.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			details = new HashMap<>();
			details.put("id", id);
			details.put("name", tbname.getText().toString());
			details.put("360view", image360downdloadlink);
			details.put("address", tbaddress.getText().toString());
			details.put("description", tbdescription.getText().toString());
			details.put("contact_information", tbcontacts.getText().toString());
			details.put("operation_hours", tboperationhours.getText().toString());
			details.put("coordinate_lat", lat);
			details.put("coordinate_lng", lng);
			details.put("category", category.get((int)(spnrcategory.getSelectedItemPosition())));
			details.put("gallery", new Gson().toJson(lmgallery));
			details.put("thumbnail", lmgallery.get((int)SelectedThumbnailIndex).get("fileDownloadUrl").toString());
			db.child(id).updateChildren(details);
		}
	}
	
	
	public String _ImageViewToBase64(final ImageView _view) {
		if(_view.getDrawable() instanceof android.graphics.drawable.BitmapDrawable ){
				android.graphics.drawable.BitmapDrawable bd = (android.graphics.drawable.BitmapDrawable) _view.getDrawable(); 
				Bitmap bm = bd.getBitmap(); 
				java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream(); 
				BitmapFactory.Options opts = new BitmapFactory.Options(); 
				opts.inPreferredConfig = Bitmap.Config.ARGB_8888; 
				bm.compress(Bitmap.CompressFormat.PNG, 100, baos); 
				byte[] imageBytes = baos.toByteArray(); 
				String imageBase64 = android.util.Base64.encodeToString(imageBytes, android.util.Base64.DEFAULT); 
			    return imageBase64;
		}
		return "";
	}
	
	
	public String _GetFileExtension(final String _filePath) {
		String fileName = Uri.parse(_filePath).getLastPathSegment();
		int lastIndexOfDot = fileName.lastIndexOf('.');
		
		if (lastIndexOfDot == -1 || lastIndexOfDot == 0) {
				return "";
		}
		
		return fileName.substring(lastIndexOfDot + 1);
	}
	
	public class RvgalleryAdapter extends RecyclerView.Adapter<RvgalleryAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RvgalleryAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cvpictures, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final Button BtnSelectAsThumbnail = _view.findViewById(R.id.BtnSelectAsThumbnail);
			final Button BtnRemove = _view.findViewById(R.id.BtnRemove);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			BtnSelectAsThumbnail.setVisibility(View.VISIBLE);
			AJCode.setRoundedRipple(BtnSelectAsThumbnail,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFA5D6A7);
			AJCode.setRoundedRipple(BtnRemove,8,8,8,8,0xFFEF5350,0,Color.TRANSPARENT,0xFFFFCDD2);
			if (lmgallery.get((int)_position).get("uploaded").toString().equals("yes")) {
				Glide.with(getApplicationContext()).load(Uri.parse(lmgallery.get((int)_position).get("fileDownloadUrl").toString())).into(imageview1);
			}
			else {
				imageview1.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(lmgallery.get((int)_position).get("filePath").toString(), 1024, 1024));
			}
			if (lmgallery.get((int)_position).get("thumbnail").toString().equals("yes")) {
				BtnSelectAsThumbnail.setVisibility(View.GONE);
			}
			BtnRemove.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					if (UpdateAction) {
						_firebase_storage.getReferenceFromUrl(lmgallery.get((int)_position).get("fileDownloadUrl").toString()).delete().addOnSuccessListener(_storage_delete_success_listener).addOnFailureListener(_storage_failure_listener);
					}
					lmgallery.remove((int)(_position));
					_updateRvGallery();
				}
			});
			BtnSelectAsThumbnail.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					BtnSelectAsThumbnail.setVisibility(View.GONE);
					_SelectThumbnail(_position);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}