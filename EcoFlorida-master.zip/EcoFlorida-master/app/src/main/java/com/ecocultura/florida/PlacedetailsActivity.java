package com.ecocultura.florida;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class PlacedetailsActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> details = new HashMap<>();
	private String longdescription = "";
	private String shortdescription = "";
	private boolean UseLongDescription = false;
	private String userid = "";
	private String favoriteId = "";
	private HashMap<String, Object> favoriteMap = new HashMap<>();
	private String place_id = "";
	private DatabaseReference database;
	private DatabaseReference userFavorites;
	private DatabaseReference databaseRef;
	private String viewImgType = "";
	private String viewImgUrl = "";
	private String detailsMap = "";
	
	private ArrayList<HashMap<String, Object>> lmshowcase = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmfavorites = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> lmfeedbacks = new ArrayList<>();
	
	private ScrollView vs;
	private LinearLayout main;
	private CardView boxHeader;
	private LinearLayout linear5;
	private LinearLayout linear2;
	private LinearLayout linear4;
	private CardView cardview1;
	private LinearLayout linear6;
	private LinearLayout btnBack;
	private LinearLayout linear3;
	private LinearLayout btnFavoriteToggle;
	private ImageView imageview2;
	private ImageView imageview3;
	private ImageView thumbnail;
	private TextView name;
	private Button btn360preview;
	private Button btnWriteSomeFeedback;
	private Button btnRoute;
	private TextView txtdetails;
	private TextView textview2;
	private TextView txtoperationhours;
	private TextView textview3;
	private TextView txtcontactinformation;
	private TextView textview5;
	private TextView txtaddress;
	private TextView textview7;
	private LinearLayout BoxHeritage;
	private TextView textview8;
	private LinearLayout BoxFeedbacks;
	private LinearLayout BoxGalleryEmpty;
	private RecyclerView RvGallery;
	private TextView textview4;
	private LinearLayout BoxFeedbacksEmpty;
	private ListView lv;
	private TextView textview9;
	
	private FirebaseAuth fbauth;
	private OnCompleteListener<AuthResult> _fbauth_create_user_listener;
	private OnCompleteListener<AuthResult> _fbauth_sign_in_listener;
	private OnCompleteListener<Void> _fbauth_reset_password_listener;
	private OnCompleteListener<Void> fbauth_updateEmailListener;
	private OnCompleteListener<Void> fbauth_updatePasswordListener;
	private OnCompleteListener<Void> fbauth_emailVerificationSentListener;
	private OnCompleteListener<Void> fbauth_deleteUserListener;
	private OnCompleteListener<Void> fbauth_updateProfileListener;
	private OnCompleteListener<AuthResult> fbauth_phoneAuthListener;
	private OnCompleteListener<AuthResult> fbauth_googleSignInListener;
	
	private TimerTask tmr;
	private DatabaseReference dbfavorites = _firebase.getReference("favorites");
	private ChildEventListener _dbfavorites_child_listener;
	private Intent i = new Intent();
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.placedetails);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vs = findViewById(R.id.vs);
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		linear5 = findViewById(R.id.linear5);
		linear2 = findViewById(R.id.linear2);
		linear4 = findViewById(R.id.linear4);
		cardview1 = findViewById(R.id.cardview1);
		linear6 = findViewById(R.id.linear6);
		btnBack = findViewById(R.id.btnBack);
		linear3 = findViewById(R.id.linear3);
		btnFavoriteToggle = findViewById(R.id.btnFavoriteToggle);
		imageview2 = findViewById(R.id.imageview2);
		imageview3 = findViewById(R.id.imageview3);
		thumbnail = findViewById(R.id.thumbnail);
		name = findViewById(R.id.name);
		btn360preview = findViewById(R.id.btn360preview);
		btnWriteSomeFeedback = findViewById(R.id.btnWriteSomeFeedback);
		btnRoute = findViewById(R.id.btnRoute);
		txtdetails = findViewById(R.id.txtdetails);
		textview2 = findViewById(R.id.textview2);
		txtoperationhours = findViewById(R.id.txtoperationhours);
		textview3 = findViewById(R.id.textview3);
		txtcontactinformation = findViewById(R.id.txtcontactinformation);
		textview5 = findViewById(R.id.textview5);
		txtaddress = findViewById(R.id.txtaddress);
		textview7 = findViewById(R.id.textview7);
		BoxHeritage = findViewById(R.id.BoxHeritage);
		textview8 = findViewById(R.id.textview8);
		BoxFeedbacks = findViewById(R.id.BoxFeedbacks);
		BoxGalleryEmpty = findViewById(R.id.BoxGalleryEmpty);
		RvGallery = findViewById(R.id.RvGallery);
		textview4 = findViewById(R.id.textview4);
		BoxFeedbacksEmpty = findViewById(R.id.BoxFeedbacksEmpty);
		lv = findViewById(R.id.lv);
		textview9 = findViewById(R.id.textview9);
		fbauth = FirebaseAuth.getInstance();
		
		btnBack.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		btnFavoriteToggle.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (_CheckIfAlreadyFavorite(place_id)) {
					imageview3.setImageResource(R.drawable.heart);
				}
				else {
					imageview3.setImageResource(R.drawable.heartfilled);
				}
				_ToggleFavorite(place_id, details);
			}
		});
		
		thumbnail.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("url", viewImgUrl);
				i.setClass(getApplicationContext(), Place360viewActivity.class);
				startActivity(i);
			}
		});
		
		btn360preview.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("url", viewImgUrl);
				i.setClass(getApplicationContext(), Place360viewActivity.class);
				startActivity(i);
			}
		});
		
		btnWriteSomeFeedback.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				MainActivity.i.putExtra("data", new Gson().toJson(details));
				MainActivity.i.setClass(getApplicationContext(), WritefeedbackActivity.class);
				startActivity(MainActivity.i);
			}
		});
		
		btnRoute.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.putExtra("data", detailsMap);
				i.setClass(getApplicationContext(), PlacemapActivity.class);
				startActivity(i);
			}
		});
		
		txtdetails.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (longdescription.length() > 200) {
					if (UseLongDescription) {
						txtdetails.setText(longdescription);
						UseLongDescription = false;
					}
					else {
						txtdetails.setText(shortdescription);
						UseLongDescription = true;
					}
				}
			}
		});
		
		_dbfavorites_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbfavorites.addChildEventListener(_dbfavorites_child_listener);
		
		fbauth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		fbauth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		fbauth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_fbauth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_design();
		details = new Gson().fromJson(getIntent().getStringExtra("data"), new TypeToken<HashMap<String, Object>>(){}.getType());
		detailsMap = getIntent().getStringExtra("data");
		place_id = details.get("id").toString();
		userid = FirebaseAuth.getInstance().getCurrentUser().getUid();
		_LoadUserFavorites();
		_LoadFeedbacksAndRating();
		UseLongDescription = true;
		Glide.with(getApplicationContext()).load(Uri.parse(details.get("thumbnail").toString())).into(thumbnail);
		name.setText(details.get("name").toString());
		longdescription = details.get("description").toString();
		if (longdescription.length() > 200) {
			shortdescription = longdescription.substring((int)(0), (int)(200)) + "\n\n...\nSee More";
			txtdetails.setText(shortdescription);
		}
		else {
			txtdetails.setText(longdescription);
		}
		txtoperationhours.setText(details.get("operation_hours").toString());
		txtcontactinformation.setText(details.get("contact_information").toString());
		txtaddress.setText(details.get("address").toString());
		lmshowcase = new Gson().fromJson(details.get("gallery").toString(), new TypeToken<ArrayList<HashMap<String, Object>>>(){}.getType());
		BoxGalleryEmpty.setVisibility(View.GONE);
		RvGallery.setVisibility(View.GONE);
		if (lmshowcase.size() > 0) {
			RvGallery.setVisibility(View.VISIBLE);
			RvGallery.setAdapter(new RvGalleryAdapter(lmshowcase));
			RvGallery.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		}
		else {
			BoxGalleryEmpty.setVisibility(View.VISIBLE);
		}
		viewImgUrl = details.get("360view").toString();
		tmr = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						if (_CheckIfAlreadyFavorite(place_id)) {
							imageview3.setImageResource(R.drawable.heartfilled);
						}
						else {
							imageview3.setImageResource(R.drawable.heart);
						}
					}
				});
			}
		};
		_timer.schedule(tmr, (int)(500));
	}
	
	public void _LoadUserFavorites() {
		database = FirebaseDatabase.getInstance().getReference();
		DatabaseReference userFavorites = database.child("favorites");
		userFavorites.orderByChild("userid")
		.equalTo(userid).addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataSnapShot) {
				lmfavorites.clear();
				for (DataSnapshot favoriteSnapshot : dataSnapShot.getChildren()) {
					HashMap<String, Object> favoriteData = (HashMap<String, Object>) favoriteSnapshot.getValue();
					lmfavorites.add(favoriteData);
				}
				MainActivity.sp.edit().putString("userFavorites", new Gson().toJson(lmfavorites)).commit();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public boolean _CheckIfAlreadyFavorite(final String _place_id) {
		for(int _repeat12 = 0; _repeat12 < (int)(lmfavorites.size()); _repeat12++) {
			if (lmfavorites.get((int)_repeat12).get("place_id").toString().equals(_place_id)) {
				return (true);
			}
		}
		return (false);
	}
	
	
	public void _ToggleFavorite(final String _place_id, final HashMap<String, Object> _favorite_map) {
		if (_CheckIfAlreadyFavorite(_place_id)) {
			dbfavorites.child(_GetFavoriteId(_place_id)).removeValue();
		}
		else {
			favoriteId = dbfavorites.push().getKey();
			favoriteMap = new HashMap<>();
			favoriteMap.put("id", favoriteId);
			favoriteMap.put("place_id", _place_id);
			favoriteMap.put("userid", userid);
			favoriteMap.put("name", _favorite_map.get("name").toString());
			favoriteMap.put("thumbnail", _favorite_map.get("thumbnail").toString());
			favoriteMap.put("category", _favorite_map.get("category").toString());
			favoriteMap.put("address", _favorite_map.get("address").toString());
			dbfavorites.child(favoriteId).updateChildren(favoriteMap);
		}
		_LoadUserFavorites();
	}
	
	
	public String _GetFavoriteId(final String _place_id) {
		for(int _repeat12 = 0; _repeat12 < (int)(lmfavorites.size()); _repeat12++) {
			if (lmfavorites.get((int)_repeat12).get("place_id").toString().equals(_place_id)) {
				return (lmfavorites.get((int)_repeat12).get("id").toString());
			}
		}
		return ("");
	}
	
	
	public void _design() {
		// Radius
		int _buttonLeftTop = 8;
		int _buttonRightTop = 8;
		int _buttonRightBottom = 8;
		int _buttonLeftBottom = 8;
		// Border
		int _buttonBorderColor = Color.TRANSPARENT;
		int _buttonBorderStroke = 0;
		//Background
		int _buttonBackgroundColor = 0xFF3A5245;
		int _buttonRippleColor = 0xFFDCEDC8;
		
		AJCode.setRoundedRipple(btnWriteSomeFeedback,_buttonLeftTop,_buttonRightTop,_buttonRightBottom,_buttonLeftBottom,_buttonBackgroundColor,_buttonBorderStroke,_buttonBorderColor,_buttonRippleColor);
		AJCode.setRoundedRipple(btn360preview,_buttonLeftTop,_buttonRightTop,_buttonRightBottom,_buttonLeftBottom,_buttonBackgroundColor,_buttonBorderStroke,_buttonBorderColor,_buttonRippleColor);
	}
	
	
	public void _LoadFeedbacksAndRating() {
		databaseRef = FirebaseDatabase.getInstance().getReference();
		DatabaseReference favoritesRef = databaseRef.child("feedbacks");
		favoritesRef.orderByChild("place_id")
		.equalTo(place_id).addListenerForSingleValueEvent(new ValueEventListener() {
			 @Override
			public void onDataChange(DataSnapshot dataFavoriteSnapShot) {
				lmfeedbacks.clear();
				for (DataSnapshot favoriteSnapshot : dataFavoriteSnapShot.getChildren()) {
					HashMap<String, Object> favoriteData = (HashMap<String, Object>) favoriteSnapshot.getValue();
					lmfeedbacks.add(favoriteData);
				}
				_LoadFeedbacksAndRatingRv();
			}
			@Override
			public void onCancelled(DatabaseError databaseError) {
				SketchwareUtil.showMessage(getApplicationContext(), databaseError.getMessage());
			}
			 });
	}
	
	
	public void _LoadFeedbacksAndRatingRv() {
		BoxFeedbacksEmpty.setVisibility(View.GONE);
		lv.setVisibility(View.GONE);
		if (lmfeedbacks.size() == 0) {
			BoxFeedbacksEmpty.setVisibility(View.VISIBLE);
		}
		else {
			lv.setVisibility(View.VISIBLE);
			lv.setAdapter(new LvAdapter(lmfeedbacks));
			((BaseAdapter)lv.getAdapter()).notifyDataSetChanged();
		}
	}
	
	public class RvGalleryAdapter extends RecyclerView.Adapter<RvGalleryAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public RvGalleryAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.cvgallery, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout BoxSlideshowItem = _view.findViewById(R.id.BoxSlideshowItem);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final ImageView thumbnail = _view.findViewById(R.id.thumbnail);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("fileDownloadUrl").toString())).into(thumbnail);
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class LvAdapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public LvAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cvcomment, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final TextView name = _view.findViewById(R.id.name);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final TextView feedback = _view.findViewById(R.id.feedback);
			final ImageView imgStar1 = _view.findViewById(R.id.imgStar1);
			final ImageView imgStar2 = _view.findViewById(R.id.imgStar2);
			final ImageView imgStar3 = _view.findViewById(R.id.imgStar3);
			final ImageView imgStar4 = _view.findViewById(R.id.imgStar4);
			final ImageView imgStar5 = _view.findViewById(R.id.imgStar5);
			
			name.setText(_data.get((int)_position).get("name").toString());
			feedback.setText(_data.get((int)_position).get("comment").toString());
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 5) {
				imgStar1.setImageResource(R.drawable.star200green);
				imgStar2.setImageResource(R.drawable.star200green);
				imgStar3.setImageResource(R.drawable.star200green);
				imgStar4.setImageResource(R.drawable.star200green);
				imgStar5.setImageResource(R.drawable.star200green);
			}
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 4) {
				imgStar1.setImageResource(R.drawable.star200green);
				imgStar2.setImageResource(R.drawable.star200green);
				imgStar3.setImageResource(R.drawable.star200green);
				imgStar4.setImageResource(R.drawable.star200green);
				imgStar5.setImageResource(R.drawable.star200grey);
			}
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 3) {
				imgStar1.setImageResource(R.drawable.star200green);
				imgStar2.setImageResource(R.drawable.star200green);
				imgStar3.setImageResource(R.drawable.star200green);
				imgStar4.setImageResource(R.drawable.star200grey);
				imgStar5.setImageResource(R.drawable.star200grey);
			}
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 2) {
				imgStar1.setImageResource(R.drawable.star200green);
				imgStar2.setImageResource(R.drawable.star200green);
				imgStar3.setImageResource(R.drawable.star200grey);
				imgStar4.setImageResource(R.drawable.star200grey);
				imgStar5.setImageResource(R.drawable.star200grey);
			}
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 1) {
				imgStar1.setImageResource(R.drawable.star200green);
				imgStar2.setImageResource(R.drawable.star200grey);
				imgStar3.setImageResource(R.drawable.star200grey);
				imgStar4.setImageResource(R.drawable.star200grey);
				imgStar5.setImageResource(R.drawable.star200grey);
			}
			if (Double.parseDouble(_data.get((int)_position).get("rate").toString()) == 0) {
				imgStar1.setImageResource(R.drawable.star200grey);
				imgStar2.setImageResource(R.drawable.star200grey);
				imgStar3.setImageResource(R.drawable.star200grey);
				imgStar4.setImageResource(R.drawable.star200grey);
				imgStar5.setImageResource(R.drawable.star200grey);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}