package com.ecocultura.florida;

import android.webkit.JavascriptInterface;
import androidx.fragment.app.DialogFragment;
import android.widget.Button;
import android.app.Activity;
import androidx.appcompat.app.AppCompatActivity;

public class WebAppInterface {
	
	
	Activity mContext;
	public WebAppInterface(Activity c) { mContext = c; }
	
	@JavascriptInterface
	public void setDetails(String address) {
		// Handle the address received from JavaScript
		// For example, update UI components in the DialogFragment
		MainActivity.sp.edit().putString("mapdetails", address).commit();
		
	}
}