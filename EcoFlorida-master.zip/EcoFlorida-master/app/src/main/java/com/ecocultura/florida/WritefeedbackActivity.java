package com.ecocultura.florida;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.bumptech.glide.Glide;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;

public class WritefeedbackActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> data = new HashMap<>();
	private String place_id = "";
	private String userid = "";
	private HashMap<String, Object> feedbackmap = new HashMap<>();
	private String feedbackid = "";
	private HashMap<String, Object> usermap = new HashMap<>();
	
	private ScrollView vs;
	private LinearLayout main;
	private CardView boxHeader;
	private CardView cardview1;
	private CardView cardview3;
	private LinearLayout linear2;
	private LinearLayout btnToggleSidebar;
	private TextView textview1;
	private ImageView imageview2;
	private LinearLayout linear3;
	private CardView cardview2;
	private LinearLayout linear5;
	private ImageView thumbnail;
	private TextView name;
	private TextView address;
	private LinearLayout BoxForm;
	private LinearLayout inputField;
	private LinearLayout linear6;
	private LinearLayout BtnSave;
	private TextView textview3;
	private RatingBar ratingbar1;
	private TextView lblfeedback;
	private EditText tbfeedbackcomment;
	private TextView textview6;
	
	private DatabaseReference dbfeedbacks = _firebase.getReference("feedbacks");
	private ChildEventListener _dbfeedbacks_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.writefeedback);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vs = findViewById(R.id.vs);
		main = findViewById(R.id.main);
		boxHeader = findViewById(R.id.boxHeader);
		cardview1 = findViewById(R.id.cardview1);
		cardview3 = findViewById(R.id.cardview3);
		linear2 = findViewById(R.id.linear2);
		btnToggleSidebar = findViewById(R.id.btnToggleSidebar);
		textview1 = findViewById(R.id.textview1);
		imageview2 = findViewById(R.id.imageview2);
		linear3 = findViewById(R.id.linear3);
		cardview2 = findViewById(R.id.cardview2);
		linear5 = findViewById(R.id.linear5);
		thumbnail = findViewById(R.id.thumbnail);
		name = findViewById(R.id.name);
		address = findViewById(R.id.address);
		BoxForm = findViewById(R.id.BoxForm);
		inputField = findViewById(R.id.inputField);
		linear6 = findViewById(R.id.linear6);
		BtnSave = findViewById(R.id.BtnSave);
		textview3 = findViewById(R.id.textview3);
		ratingbar1 = findViewById(R.id.ratingbar1);
		lblfeedback = findViewById(R.id.lblfeedback);
		tbfeedbackcomment = findViewById(R.id.tbfeedbackcomment);
		textview6 = findViewById(R.id.textview6);
		
		btnToggleSidebar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		BtnSave.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (tbfeedbackcomment.getText().toString().equals("")) {
					SketchwareUtil.showMessage(getApplicationContext(), "Please enter  your feedback");
					return;
				}
				BtnSave.setEnabled(false);
				feedbackid = dbfeedbacks.push().getKey();
				feedbackmap = new HashMap<>();
				feedbackmap.put("place_id", place_id);
				feedbackmap.put("user_id", userid);
				feedbackmap.put("feedback_id", feedbackid);
				feedbackmap.put("rate", String.valueOf((long)(ratingbar1.getRating())));
				feedbackmap.put("comment", tbfeedbackcomment.getText().toString());
				feedbackmap.put("name", usermap.get("name").toString());
				dbfeedbacks.child(feedbackid).updateChildren(feedbackmap);
			}
		});
		
		_dbfeedbacks_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (feedbackid.equals(_childKey)) {
					SketchwareUtil.showMessage(getApplicationContext(), "Feedback was succesfully submitted.");
					finish();
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		dbfeedbacks.addChildEventListener(_dbfeedbacks_child_listener);
	}
	
	private void initializeLogic() {
		_user();
		_design();
		ratingbar1.setStepSize((float)1);
		ratingbar1.setNumStars((int)5);
		data = new Gson().fromJson(getIntent().getStringExtra("data"), new TypeToken<HashMap<String, Object>>(){}.getType());
		place_id = data.get("id").toString();
		Glide.with(getApplicationContext()).load(Uri.parse(data.get("thumbnail").toString())).into(thumbnail);
		name.setText(data.get("name").toString());
		address.setText(data.get("address").toString());
	}
	
	public void _design() {
		AJCode.setRoundedRipple(BtnSave,8,8,8,8,0xFF3A5245,0,Color.TRANSPARENT,0xFFC8E6C9);
		// Radius
		int _TbLeftTop = 8;
		int _TbRightTop = 8;
		int _TbRightBottom = 8;
		int _TbLeftBottom = 8;
		// Border
		int _TbBorderColor = 0xFF3A5245;
		int _TbBorderStroke = 2;
		//Background
		int _TbBackgroundColor = 0xFFFEFAF6;
		int _TbRippleColor = Color.TRANSPARENT;
		
		AJCode.setRoundedRipple(tbfeedbackcomment,_TbLeftTop,_TbRightTop,_TbRightBottom,_TbLeftBottom,_TbBackgroundColor,_TbBorderStroke,_TbBorderColor,_TbRippleColor);
	}
	
	
	public void _user() {
		usermap = new Gson().fromJson(MainActivity.sp.getString("user", ""), new TypeToken<HashMap<String, Object>>(){}.getType());
		userid = usermap.get("uid").toString();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}